// Tableau des centrés d'intérêts (POI)
var interestChecked = [];

// Ajoute/Retire les POI au DOM lorsqu'ils sont cochés ou non.
function isChecked(box){
  var name = $(box).attr('name');
  if($(box).prop('checked')){
    $('#interestSelected').append("<input type='hidden' name="+name+" id="+name+"Checked"+" value="+name+">");
  }
  else{
    $('#'+name+"Checked").remove()
  }
}

// Ajout des centres d'intérêts au tableau et envoie au serveur
function sendPOI(){
  if(mymap == undefined || mymap == null){
    //Affichage d'un message d'erreur
    return;
  }
  interestChecked.length = 0;
  // On regarde si il existe des intérêts ajouté au DOM
var childs = $('#interestSelected').children();
  childs.each(function(index){
    // On ajoute les intérêts au tableau
    var value = $((childs).get(index)).val();
    interestChecked.push(value);
  });
  // Si une position a été initialisée on envoie les POI au serveur, sinon un message d'erreur s'affiche.
  if(userPosition.latitude == "" && userPosition.longitude == ""){
    //Message d'erreur
    console.log("erreur");
  }
    // Envoie des POI au serveur.
      else{
        console.log(interestChecked);
        $.ajax({
          type: "POST",
          url: "http://localhost:8888/userIndex.php",
          data: {data : interestChecked,userPosition},
          success: function(response) {
            console.log(response);
            //initMap(userPosition,response, 'user');
            addPointOfInterest(layerPointOfInterestGroup, response);
          },
          dataType: 'json'
        });
      }
    }
