// Object représentant la position de l'utilisateur
var userPosition = {
  latitude: undefined,
  longitude: undefined
};

// Passage des coordonnées de géolocalisation à l'objets puis envoie au serveur
function setUserPosition(position) {
    userPosition.latitude =  position.coords.latitude,
    userPosition.longitude =  position.coords.longitude,

    console.log(userPosition);

    //Ajout aux champs cachées des coordonnées latitude et longitude
    $("#lat").val(position.coords.latitude);
    $("#lng").val(position.coords.longitude);

    //Modification/Suppression du message d'erreur
    var errorMessage = $("#infoposition").html().length
      if(errorMessage != 0)
        changeCSSErrorMessage('erase');

    // Envoie au serveur des coordonnées
    /*$.ajax({
      type: "POST",
      url: "http://localhost:8888/userIndex.php",
      data: userPosition,
      success: function(response) {
        console.log(response);*/
        initMap(userPosition,undefined, 'user');
    /*  },
      dataType: 'json'
    });*/
  }

// Demande d'autorisation de la géolocalisation à l'utilisateur
// Si la réponse est positive, setUserPosition est lancé, sinon on lance erreurPosition
function askForUserPosition(){
  if(navigator.geolocation)
    position = navigator.geolocation.getCurrentPosition(setUserPosition,erreurPosition);
}

// Retour d'erreurs relatives à la géolocalisation.
function erreurPosition(error) {
var info = "Erreur lors de la géolocalisation."
switch(error.code) {
case error.TIMEOUT:
  info += "Délais d'attente dépassé."
break;
case error.PERMISSION_DENIED:
info += "Vous avez refusé d'être géolocalisé :("
break;
case error.POSITION_UNAVAILABLE:
  info += "La position n’a pu être déterminée";
break;
case error.UNKNOWN_ERROR:
  info += "Erreur inconnue";
break;
}
//Ajout de la chaine de caractère dans la div
changeCSSErrorMessage(null);
$("#infoposition").html(info)
}

// Fonction CSS

function changeCSSErrorMessage(status){
  console.log(status);
  if(status === 'erase'){
    $('.error').css('transform', 'scale(0) rotate(-12deg)');
    $('.error').css('opacity','0');
}
    else {
    $('.error').css('transform', 'scale(1) rotate(0)');
    $('.error').css('opacity','0.8');
  }
}
