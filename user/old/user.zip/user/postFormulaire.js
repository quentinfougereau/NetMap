// Transforme une adresse en coordonnées et construit une carte
function getUserAddr() {
  if($("#postalCodeArea").val() == ""){
    //Affichage message d'erreurs
    console.log("ERREUR CODE POSTALE");
    return;
  }
  var location = $("#addrArea").val();
  location+= ','+$("#postalCodeArea").val();
  console.log(location);
  // Récupération des coordonnées sous la forme (lat,long) depuis l'adresse
  var nominatim = 'https://nominatim.openstreetmap.org/search?format=json&q='+location+',France'; //Transforme l'adresse en coordonnées
  $.getJSON(nominatim, function(data) {
  // Vérifie que les données géographiques existent
  if( data[0] != undefined){
    $("#infoposition").html("");
    // Initialisation de la position de l'utilisateur
      userPosition.latitude = data[0].lat;
      userPosition.longitude = data[0].lon;
    // Initialisation de la map
      initMap(userPosition,undefined, 'user');
      console.log(userPosition);
    }
  else{
    // Ajout du Message d'erreur (à changer par un SPAN)
    $("#infoposition").html("<span>Pas bien ce que tu as mis dans ce champs</span>");
  }
});
}
