var mymap;
var layerPositionGroup;
var layerPointOfInterestGroup;
var status = false;

function initMap(position, pointOfInterest, view){
  // Si la carte est affiché, on enlève les précédents messages d'erreurs
  $("#infoposition").html("");
  // Vérifie si la carte existe déjà ou non
  var container = L.DomUtil.get('mapid'); if(container != null){ container._leaflet_id = null; }
  // Initialise la carte et empêche toute forme de @oom
  if(view === 'visitor'){
    // Initialise la carte et empêche toute forme de zoom (view:visiteur)
    mymap =  L.map('mapid',{
        center:[position.latitude, position.longitude],
        keyboard: false,
        dragging: false,
        zoomControl: false,
        boxZoom: false,
        doubleClickZoom: false,
        scrollWheelZoom: false,
        tap: false,
        touchZoom: false,
        zoom: 15,
        minZoom: 15,
        maxZoom: 15
      });
    }
      // Initialise la carte et permet des interactions (view:user)
    else if(view === 'user') {
      mymap =  L.map('mapid',{
          center:[position.latitude, position.longitude],
          zoom: 15
      });
    }
    else{
      //Affichage d'un message d'erreur
      return;
    }

  // Initialise un groupe de markers pour afficher les points d'intérêts si il en existe
  layerPointOfInterestGroup = L.layerGroup().addTo(mymap);
  // Initialise un groupe de markers pour afficher la position de l'utilisateur
  layerPositionGroup= L.layerGroup().addTo(mymap);
  // Remplie la carte
  fillMap(mymap);
  // Ajoute un marqueur sur la position de l'utilisateur
  addPositionMarker(layerPositionGroup, position);
  //Ajoute les points d'intérêts si ils existent
  if(pointOfInterest != null)
    addPointOfInterest(layerPointOfInterestGroup,pointOfInterest)

}



// Remplie les tiles de la map
function fillMap(map){
  L.tileLayer('https://api.tiles.mapbox.com/v4/{id}/{z}/{x}/{y}.png?access_token={accessToken}', {
      attribution: 'Map data &copy; <a href="https://www.openstreetmap.org/">OpenStreetMap</a> contributors, <a href="https://creativecommons.org/licenses/by-sa/2.0/">CC-BY-SA</a>, Imagery © <a href="https://www.mapbox.com/">Mapbox</a>',
      maxZoom: 15,
      color:'red',
      id: 'mapbox.streets',
      accessToken: 'pk.eyJ1Ijoic2Vhc29ueGRrIiwiYSI6ImNqdjJlZjVxZjA1NDU0M21wbmg2eThlbnkifQ.CzDcGBZxuQgRiOuIXnea3A' //changer la clé si nécessaire
  }).addTo(map);
}

// Ajout d'un marqueur de la position de l'utilisateur sur la carte
function addPositionMarker(layerPositionGroup, position){
  // Efface les marqueurs précédants
  layerPositionGroup.clearLayers();
  var positionIcon = L.icon({
    iconUrl: 'img/position.png',
    iconSize: [40,40], // size of the icon
  });
  //Problème au niveau de l'icone
  //let marker = L.marker([position.latitude, position.longitude],{icon:positionIcon,autoPan:true}).addTo(layerPositionGroup);
  let marker = L.marker([position.latitude, position.longitude],{autoPan:true}).addTo(layerPositionGroup);
  marker.bindPopup("<b>Vous êtes ici<b>.");
  marker.on('mouseover', function (e) {
  this.openPopup();
  });
  marker.on('mouseout', function (e) {
  this.closePopup();
  });
  var circle = L.circle([position.latitude, position.longitude], {
          color: "white",
          fillColor: "red",
          fillOpacity: 0.2,
          radius: 1050,
          weight: 1
      }).addTo(layerPositionGroup);
 }

// Ajout des points d'intérêts affichés sous forme de marqueur choisis arbitrairement pour le visiteur
function addPointOfInterest(layerPointOfInterestGroup, pointOfInterest){
  // On efface les points générés lors de la dernière recherche
  layerPointOfInterestGroup.clearLayers();
  // On parcourt les données et si il s'agit de point sur la carte, on l'affiche.
  for(let data of pointOfInterest){
    getPointOfInterestAdress(data, layerPointOfInterestGroup, setPointOfInterestMarker)
  }
}

// Affiche les marqueurs sur la carte (à expliquer plus en détail)
function setPointOfInterestMarker(data, address, layer){
  console.log(data+"\n"+address+"\n"+layer)
  if(data.type === "node"){
      //A remplacé par un switch pour chaque type d'amenity
      if(data.tags.amenity === 'restaurant'){
            var restaurantIcon = L.icon({
              iconUrl: 'img/food.png',
              iconSize: [30,30], // size of the icon
            });
            var marker = L.marker([data.lat, data.lon],{icon:restaurantIcon,autoPan: false}).addTo(layerPointOfInterestGroup);
            //Ajout des informations lié au marqueur
            //A améliorer
            console.log(data);
              marker.bindPopup("<span><b>"+data.tags.name+"</b></span></br><span>"+data.tags.amenity+"</span></br><span>Adresse : "+address+"</span>")
        }
        else if(data.tags.tourism === 'museum'){
              var museumIcon = L.icon({
                iconUrl: 'img/museum.png',
                iconSize: [30,30], // size of the icon
              });
              var marker = L.marker([data.lat, data.lon],{icon:museumIcon,autoPan: false}).addTo(layerPointOfInterestGroup);
              marker.bindPopup("<span><b>"+data.tags.name+"</b></span></br></span>"+data.tags.tourism+"</span></br><span>Adresse : "+address+"</span>")
          }
        else if(data.tags.amenity === 'bench'){
                var marker = createCircleMarker(data).addTo(layerPointOfInterestGroup);
                marker.bindPopup("<b>("+data.tags.amenity+")<b><br/>"+data.tags.material)
            }
          else{
            //Affichage d'un message d'erreur
            return;}
    // On ajoute les marqueur à la carte
    marker.on('mouseover', function (e) {
    this.openPopup();
    });
    marker.on('mouseout', function (e) {
    this.closePopup();
    });
  }
}

//Récupère une addresse et la retourne à partir de lat/lon puis créé le marker (callback)
function getPointOfInterestAdress(myData,layer, callback){
  let location = "lat="+myData.lat+'&lon='+myData.lon;
  var nominatim = "https://nominatim.openstreetmap.org/reverse?format=json&"+location+"&zoom=18&addressdetails=1";
  var address ="";

  //Objet contenant les champs de l'adresse
  var POIAddress = {
    house_number: undefined,
    road: undefined,
    postcode: undefined,
    city: undefined
  };
  //Transforme les coordonnées en adresse
  $.getJSON(nominatim, function(data) {
    // Vérifie que la requête nominatim avec lat/lon retourne au moins un résultat
    if( data != undefined){
      for(let subData in data.address){
        var attrName = subData;
        switch (attrName) {
          case 'house_number':
            POIAddress.house_number=data.address[subData];
            break;
          case 'road':
            POIAddress.road=data.address[subData];
            break;
          case 'postcode':
            POIAddress.postcode=data.address[subData];
            break;
          case 'city':
            POIAddress.city=data.address[subData];
            break;
          default:
            break;
          }
        }
      for(field in POIAddress){
        if(POIAddress[field] === undefined){
          continue;
        }
        else if(field === "road" && POIAddress.city != undefined){
          address+=POIAddress[field]+", ";
        }
        else{
          address+=POIAddress[field]+" ";
        }
      }
    }
    console.log(address)
    setPointOfInterestMarker(myData, address, layer)
    });
  }



// Permet à l'utilisateur d'ajouter manuellement sa position
function addUserPositionOnClick(map){
  if(map == undefined || map == null)
    return;
    iconFollowCursor();
    map.on('click', function(e){
      var coord = e.latlng;
      console.log(coord);
      console.log(coord.lat);
      console.log(coord.lng);
      userPosition.latitude = coord.lat;
      userPosition.longitude = coord.lng;
      console.log(userPosition);
      addPositionMarker(layerPositionGroup, userPosition);
      //Requête AJAX à ajouter
      //Supprime l'évènement après que l'utilisateur ait cliqué sur la carte
      this.off('click');
      //Recentre la carte sur la positiona ajouté par l'utilisateur
      map.panTo(new L.LatLng(coord.lat, coord.lng));
      //Supprime l'image du PIN suivant le curseur
        $('#movedSelfLocate-pin').remove();
    });
  }

//Fonction inutile on peut lancer celle du desssus (à supprimer)
function setStatus(mymap,layerPositionGroup){
  addUserPositionOnClick(mymap);
};

// L'icone suit le curseur de l'utilisateur jusqu'au click
function iconFollowCursor(){
  //Ajoute l'image dans le DOM
    $('#button').prepend('<img id="movedSelfLocate-pin" src="img/position.png" />');
$(document).mousemove(function(e) {
  $('#movedSelfLocate-pin').offset({
      left: e.pageX-12,
      top: e.pageY-28
  });
});
}

function createCircleMarker(position){
  // Change the values of these options to change the symbol's appearance
  let options = {
    radius: 8,
    fillColor: "red",
    color: "black",
    weight: 1,
    opacity: 1,
    fillOpacity: 0.8
  }
  return L.circleMarker(position);
}
